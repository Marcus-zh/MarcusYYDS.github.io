---
title: 即刻短文
aplay: false
keywords: essay,Marcus
description: Marcus的 essay
date: 2022-10-01 11:13:24
comments: true
aside: false
type: essay
---
<script>
  if(1) {
    let url = 'https://memos.marcus233.top'
    let essay = document.getElementById('waterfall').innerHTML
    document.getElementById('waterfall').innerHTML = ""
    fetch(url + '/api/v1/memo?creatorId=1&tag=说说&limit=30').then(res => res.json()).then(data => { 
        let items = [],
            html = ''
        data.forEach(item => { items.push(Format(item)) });
        if (items.length == 30) document.querySelector('.limit').style.display = 'block';
        items.forEach(item => {
            html += `<li class='item'><div class='bber-content'><p class='datacont'>${item.content}</p></div><hr><div class='bber-bottom'><div class='bber-info'><div class='bber-info-time'><i class='heofont icon-calendar-todo-fill'></i><time class='datatime' datetime='${item.date}'>${new Date(item.date).toISOString()}</time></div></div><div class="bber-info-from"><i class="fa-solid fa-note-sticky"></i>来自memos</div><a class='bber-reply' onclick='rm.rightMenuCommentText(&quot;${item.text}&quot;);' data-pjax-state=''><i class='heofont icon-chat-1-fill'></i></a></div></li>`
        })
        document.getElementById('waterfall').innerHTML = html + essay;
        document.getElementById('waterfall').style.opacity = 1;
    })
    // 页面内容格式化
    function Format(item) {
        let date = new Date(item.createdTs * 1000),
            content = item.content,
            tag = item.content.match(/\{(.*?)\}/g),
            imgs = content.match(/!\[.*\]\(.*?\)/g), 
            text = ''
        if (imgs) imgs = imgs.map(item => { return item.replace(/!\[.*\]\((.*?)\)/, '$1') })
        if (item.resourceList.length) {
            if (!imgs) imgs = []
            item.resourceList.forEach(t => {
                if (t.externalLink) imgs.push(t.externalLink)
                else imgs.push(`${url}/o/r/${t.id}/${t.publicId}/${t.filename}`)
            })
        }
        text = content.replace(/#(.*?)\s/g, '').replace(/\!\[(.*?)\]\((.*?)\)/g, '').replace(/\{(.*?)\}/g, '')
        content = text.replace(/\[(.*?)\]\((.*?)\)/g, `<a href="$2">@$1</a>`);
        if (imgs) {
            content += `<div class="bber-content-img">`
            imgs.forEach(e => content += `<a href="${e}" data-fancybox="images" data-caption="" class="fancybox" data-srcset="${e}"><img class="bber-content-image-self entered loading" src="${e}" onerror="this.onerror=null;this.src='https://bu.dusays.com/2023/03/03/6401a79030db5.png'" title="即刻短文配图" data-ll-status="loading"></a>` // 2023-02-06更新
            )
            content += '</div>'
        }
        return {
            content: content,
            tag: tag ? tag[0].replace(/\{(.*?)\}/,'$1') : '无标签',
            date: date,
            text: text.replace(/\[(.*?)\]\((.*?)\)/g, '[链接]' + `${imgs?'[图片]':''}`)
        }
    }
  }
</script>
<script type="text/javascript" src="/lib/waterfall.min.js"></script>